package com.example.tictactoe;

public class Presenter implements IPresenter
{

    private Model model;
    private IView view;
    private char computer = 'O';

    public Presenter(IView view)
    {
        this.view = view;
        this.model = new Model();
        this.model.startGame();
    }

    @Override
    public void restartGame()
    {
        // clear view and model
        this.model.startGame();
        this.view.clearBoard();

    }

    @Override
    public void userClick(int row, int col)
    {
        // create move and pass to model
        Move m = new Move(row,col);
        this.model.userTurn(m);

        // check if game over or win
        if( this.model.gameOver() == 0) {
            this.view.displayMessage("No More Turns");
            this.view.displayEndGame();

        }
        else {

            Move computerMove = this.model.computerTurn();
            if(m!=null)
                this.view.markButton(computerMove.getRow(),computerMove.getCol(),computer);
            // check if game over or win
            if (this.model.gameOver() == 0)
                this.view.displayMessage("No More Turns");
        }



    }
}
