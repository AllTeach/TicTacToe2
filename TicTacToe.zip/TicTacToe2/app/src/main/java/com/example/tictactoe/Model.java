package com.example.tictactoe;

public class Model
{
    private static final  int ROWS=3;
    private static final  int COLS=3;
    private char[][] board;
    private int numTurns=0;
    public Model()
    {
        board = new char[ROWS][COLS];
    }
    public void startGame() {
        this.numTurns = 0;
        // clear board
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                this.board[i][j] = ' ';
            }

        }
    }

    // at the moment check only num turns
    // add here win check
    public int gameOver()
    {
        if(numTurns == ROWS*COLS)
            return 0;
        return 1;

    }

    public void userTurn(Move m)
    {
        board[m.getRow()][m.getCol()] = 'X';
        this.numTurns++;
    }
    /// at the moment find the first available move
    public Move computerTurn()
    {
        boolean found = false;
        Move m=null;

        for(int i=0;i<ROWS;i++)
        {
            for(int j=0;j<COLS;j++)
            {
                if(this.board[i][j]==' ')
                {
                    this.numTurns++;

                    m=new Move(i,j);
                    this.board[i][j]='O';
                    return m;


                }
            }

        }
        return m;



    }

}

