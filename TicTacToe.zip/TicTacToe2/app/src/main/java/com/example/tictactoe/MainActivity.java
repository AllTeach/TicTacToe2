package com.example.tictactoe;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, IView {
    private LinearLayout llMainDynamic;
    private IPresenter presenter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         initViews();
        createBoard();

        // create presenter
        presenter = new Presenter(this);


    }

    private void initViews()
    {
        llMainDynamic=findViewById(R.id.llDynamic);

    }

    private void createBoard()
    {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int width = metrics.widthPixels;
        int height =metrics.heightPixels;
        Toast.makeText(this, "width&height are  " +width + " , " + height, Toast.LENGTH_SHORT).show();

        // we will create the board in the following way:
        //   1/5  margin   3/5 board   1/5 margin
        LinearLayout linearLayoutBoard = new LinearLayout(this);
        linearLayoutBoard.setOrientation(LinearLayout.VERTICAL);
        linearLayoutBoard.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
        //linearLayoutBoard.setGravity(Gravity.CENTER);

        // define layoutparams for each row
        LinearLayout.LayoutParams rowLayout= new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowLayout.setMargins(width/5,1,width/5,1);

        // define rows and cols - can get from user
        int rows = 3;
        int cols=3 ;
        // create a new row  horizontal linear layout
        // define lp for each element in the board
        LinearLayout.LayoutParams elementLayout= new LinearLayout.LayoutParams(width/5, LinearLayout.LayoutParams.WRAP_CONTENT);
        LinearLayout rowInBoard;
        for(int i=0;i<rows;i++)
        {
            rowInBoard = new LinearLayout(this);
            rowInBoard.setLayoutParams(rowLayout);
            rowInBoard.setOrientation(LinearLayout.HORIZONTAL);
            for (int j=0;j<cols;j++)
            {
                Button b = new Button(this);
                b.setLayoutParams(elementLayout);
                b.setTag(i +"" + j);
           //     b.setText(i+ "," + j);
                b.setOnClickListener(this);
                rowInBoard.addView(b);
            }
            //add the row to the layout
            linearLayoutBoard.addView(rowInBoard);
        }
        llMainDynamic.addView(linearLayoutBoard);
    }

    @Override
    public void onClick(View view) {
        String tag = view.getTag().toString();
        Toast.makeText(this,tag,Toast.LENGTH_SHORT).show();
        // pass button row and col to presenter
        int row = tag.charAt(0)-'0';
        int col = tag.charAt(1)-'0';
        // disable user click
        ((Button)view).setText(""+'X');
        ((Button)view).setClickable(false);
        this.presenter.userClick(row,col);



    }

    @Override
    public void displayEndGame() {

            final AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
            alertDialog.setTitle("End Game Dialog");
            alertDialog.setMessage("Would you like to play again?");
            alertDialog.setIcon(R.drawable.ic_launcher_background);
            alertDialog.setCancelable(true);

            // in case clicked YES
            // remove from list and then from database
            alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    MainActivity.this.presenter.restartGame();
                    dialog.dismiss();
                }
            });
            alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    MainActivity.this.finish();
                    dialog.dismiss();
                }
            });

            AlertDialog dialog= alertDialog.create();
            dialog.show();
        }


    @Override
    public void markButton(int i, int j, char letter)
    {
        View parentView = findViewById( R.id.llDynamic );
        Button button = parentView.findViewWithTag(i+""+j);
        button.setText(""+letter);

    }

    @Override
    public void displayMessage(String message) {
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();

    }
    @Override
    public void clearBoard() {
        ViewGroup parentView = findViewById(R.id.llDynamic);

        // clear all button data and set clickable to true
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                Button button = parentView.findViewWithTag(i+""+j);
                button.setText("");
                button.setClickable(true);
            }
        }
    }
}