package com.example.tictactoe;

public interface IPresenter
{
    void userClick(int row,int col);
    void restartGame();
}
